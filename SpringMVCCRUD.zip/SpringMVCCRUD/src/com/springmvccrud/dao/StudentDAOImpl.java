package com.springmvccrud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springmvccrud.dto.Student;

@Repository("studentdao")
public class StudentDAOImpl implements StudentDAO {
	
	@PersistenceContext
	EntityManager em;

	@Override
	@Transactional
	public void addStudent(Student student) {
		
		em.persist(student);
		em.flush();
		
		}

	@Override
	@Transactional
	public Student getStudent(int id) {
	
		Query query = em.createQuery("From Student where id=:tid");
		query.setParameter("tid", id);
		Student student = (Student) query.getResultList().get(0);
		return student;
	}

	@Override
	@Transactional
	public void updateStudent(int id, String mobno) {
		
		Query query = em.createQuery("Update Student set mobno=:tmobno where id=:tid");
		query.setParameter("tmobno", mobno);
		query.setParameter("tid", id);
		query.executeUpdate();
		
	}

	@Override
	@Transactional
	public void deleteStudent(int id) {
		Query query = em.createQuery("Delete from Student where id=:tid ");
		query.setParameter("tid", id);
		query.executeUpdate();
		
		
	}

	@Override
	public List<Student> getAll() {
		Query query = em.createQuery("FROM Student");
		@SuppressWarnings("unchecked")
		List<Student> list = query.getResultList();
		return list;
	}
	
	

}
