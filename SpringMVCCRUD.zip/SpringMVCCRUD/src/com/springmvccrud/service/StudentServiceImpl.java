package com.springmvccrud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvccrud.dao.StudentDAO;
import com.springmvccrud.dto.Student;

@Service("studentservice")
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	StudentDAO studentdao;

	@Override
	public void addStudent(Student student) {
		
		studentdao.addStudent(student);
		
		}

	@Override
	public Student getStudent(int id) {
		
		return studentdao.getStudent(id);
	}

	@Override
	public void updateStudent(int id, String mobno) {
		studentdao.updateStudent(id, mobno);
		
	}

	@Override
	public void deleteStudent(int id) {
		
		studentdao.deleteStudent(id);
	}

	@Override
	public List<Student> getAll() {
		
		return studentdao.getAll();
	}

	}


