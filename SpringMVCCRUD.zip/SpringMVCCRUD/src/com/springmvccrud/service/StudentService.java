package com.springmvccrud.service;

import java.util.List;

import com.springmvccrud.dto.Student;

public interface StudentService {
	
	public void addStudent(Student student);
	
	public Student getStudent(int id);
	
	public void updateStudent(int id, String mobno);
	
	public void deleteStudent(int id);
	
	public List<Student> getAll();

}
