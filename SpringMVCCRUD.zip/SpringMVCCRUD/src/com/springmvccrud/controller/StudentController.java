package com.springmvccrud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvccrud.dto.Student;
import com.springmvccrud.service.StudentService;

@RequestMapping(value = "/")
@Controller
public class StudentController {
	
	@Autowired
	StudentService studentservice;
	
	@RequestMapping(value="addmobile", method = RequestMethod.GET)
	public String dispalyAddStudent(Model model) {
		model.addAttribute("my", new Student());
		return "AddStudent";
	}
	
	@RequestMapping(value = "adddata", method = RequestMethod.POST)
	public String addStudentData(@ModelAttribute("my") Student student, BindingResult result){
		
		if(result.hasErrors()){
			
			return "error";
		}
		studentservice.addStudent(student);		
		return "success";
	}
	
	@RequestMapping(value="searchstudent", method = RequestMethod.GET)
	public String displaySearchStudent(Model model) {
		
		model.addAttribute("yy", new Student());
		return "SearchStudent";
	}
	
	@RequestMapping(value = "searchstud", method = RequestMethod.POST )
	public ModelAndView searchStudent(@ModelAttribute("yy") Student student) {
		
		Student studsearch = studentservice.getStudent(student.getId());
		System.out.println(studsearch);
		return new ModelAndView("ShowStudent","temp",studsearch);
		
	}
	
	@RequestMapping(value = "updatestudent", method = RequestMethod.GET)
	public String displayUpdateStudent(Model model) {
		
		model.addAttribute("uu",new Student());
		return "UpdateStudent";
	}
	
	@RequestMapping(value = "updatestud", method = RequestMethod.POST)
	public String showUpdatedStudent(@ModelAttribute("uu") Student student, BindingResult result) {
		
if(result.hasErrors()){
			
			return "errorupdate";
		}

		studentservice.updateStudent(student.getId(), student.getMobno());
		
		return "successupdate";
		
	}
	
	@RequestMapping(value="deletestudent", method=RequestMethod.GET)
	public String displayDeleteStudent(Model model) {
		
		model.addAttribute("dd",new Student());
		return "DeleteStudent";
	}
	
	@RequestMapping(value="delete", method=RequestMethod.POST)
	public String deleteStudent(@ModelAttribute("dd") Student student, BindingResult result) {
		if(result.hasErrors()) {
			
			return "deleteerror";
		}
		studentservice.deleteStudent(student.getId());
		return "deletesuccess";
		
	}
	
	@RequestMapping(value="displayall", method=RequestMethod.GET)
	public ModelAndView displayAll() {
		List<Student> mylist = studentservice.getAll();
		
		return new ModelAndView("DisplayAll","l",mylist);
		
}

}