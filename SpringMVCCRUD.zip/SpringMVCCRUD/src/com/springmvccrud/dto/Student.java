package com.springmvccrud.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Student")
public class Student {
	
	@Id
	@Column(name = "StudentID")
	Integer id;
	
	@Column(name = "Name")
	String name;
	
	@Column(name = "Age")
	Integer age;
	
	@Column(name = "MobileNo")
	String mobno;
	
	public Student() {
		
	}
	
	
	
	public Student(Integer id, String name, Integer age, String mobno) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.mobno = mobno;
	}
	public Integer getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}



	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + ", mobno=" + mobno + "]";
	}
	
	
	
	

}
